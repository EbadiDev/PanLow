<h1 align="left">TgGuard bot with fast speed and high power</h1>
--

<p align="center"> <img class="td" style="vertical-align: middle;" src="https://memberplus.gq/tg2.png" alt="" width="500" height="260" /></p>

***

## Installation

Debian/Ubuntu and derivatives:
```bash
cd $home && git clone https://github.com/sajjad-021/tgGuard.git; cd tgGuard; chmod +x launch.sh; ./launch.sh install; ./launch.sh

     # you can use the option --no-download and only configure TgGuard
     # Will ask you for a phone number & confirmation code.
```

***

## Tmux & ANTI CRASH :
```bash
tmux new-session -s script "bash steady.sh -t"
```

***

## Sudo And Bot
After you run the bot for first time, send it `!id`. Get your ID and stop the bot.

Open ./bot/bot.lua and add your ID to the "sudo_users" section in the following format:
```
    sudo_users = {
    247134702,
    0,
    YourID
  }
```
add your bot ID at line 4
add your ID at line 82 in bot.lua247134702
add your ID at line 235 in tools.lua
Then restart the bot.

***

# [Creator](https://telegram.me/sajjad_021)
-
# [Channel](https://telegram.me/tgMember)
			
----------
